<?php
require_once "auth.php";
// Demo credentials (for learning only)
const DEMO_USER = "student";
const DEMO_PASS = "Lab03!";
// If already logged in, go to dashboard
if (!empty($_SESSION['logged_in'])) {
header("Location: dashboard.php");
exit;
}
$errors = [];
$username = "";
// Handle POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";
// Server-side validation
if ($username === "") $errors[] = "Username is required.";
if ($password === "") $errors[] = "Password is required.";
// Verify credentials only if validation passed
if (empty($errors)) {
if ($username === DEMO_USER && $password === DEMO_PASS) {
// Regenerate session id to prevent session fixation
session_regenerate_id(true);
$_SESSION["logged_in"] = true;
$_SESSION["username"] = $username;
$_SESSION["login_time"] = date("Y-m-d H:i:s");
header("Location: dashboard.php");
exit;
} else {
$errors[] = "Invalid username or password.";
}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lab 03 - Login</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
<h1>Lab 03: Login</h1>
<div class="card">
<?php if (!empty($errors)): ?>
<div class="alert alert-error">
<strong>Please fix the following:</strong>
<ul>
<?php foreach ($errors as $e): ?>
<li><?= htmlspecialchars($e) ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<form method="post" action="login.php" novalidate>
<label for="username">Username</label>
<input id="username" name="username" value="<?= htmlspecialchars($username) ?>"
autocomplete="username">
<label for="password">Password</label>
<input id="password" name="password" type="password" autocomplete="current-
password">
<button type="submit">Log in</button>
</form>
<p class="small">
Demo credentials for marking:<br>
Username: <strong>student</strong> | Password: <strong>Lab03!</strong>
</p>
<p>Created by Sherry Ma. Copyright 2026.</p> <!-- change it to your first and last
name. -->
</div>
</div>
</body>
</html>