<?php
/* 
Lab 04 Documentation Page
Student: Joyce Tang Thi
Date: 2026-05-19
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>lab04_joyce - MySQL Documentation</title>
<style>
body { font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }
h1, h2, h3 { margin-bottom: 6px; }
code { background: #f3f3f3; padding: 2px 6px; border-radius: 4px; }
pre { background: #f3f3f3; padding: 12px; border-radius: 6px; overflow-x: auto; }
table { border-collapse: collapse; width: 100%; max-width: 720px; margin-top: 10px; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
th { background: #f6f6f6; }
</style>
</head>

<body>

<h1>Lab 04: MySQL Fundamentals (phpMyAdmin)</h1>

<p><strong>Name:</strong> Joyce Tang Thi<br>
<strong>Date:</strong> 2026-05-19</p>

<!-- DATABASE -->
<h2>Database</h2>
<p><strong>Database name:</strong> <code>lab04_joyce</code></p>

<!-- TABLE PURPOSE -->
<h2>Tables and Purpose</h2>
<ul>
<li><strong>customers</strong> — Stores customer information (parent table).</li>
<li><strong>orders</strong> — Stores order records and links each order to a customer using <code>customer_id</code>.</li>
</ul>

<!-- FIELDS -->
<h2>Table Fields</h2>

<h3>customers</h3>
<ul>
<li><code>customer_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
<li><code>first_name</code> — VARCHAR(50)</li>
<li><code>last_name</code> — VARCHAR(50)</li>
<li><code>email</code> — VARCHAR(120)</li>
<li><code>created_at</code> — DATETIME</li>
</ul>

<h3>orders</h3>
<ul>
<li><code>order_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
<li><code>customer_id</code> — INT (FOREIGN KEY → customers.customer_id)</li>
<li><code>order_date</code> — DATE</li>
<li><code>total_amount</code> — DECIMAL(8,2)</li>
<li><code>status</code> — VARCHAR(30)</li>
</ul>

<!-- SAMPLE DATA -->
<h2>Sample Data Inserted</h2>

<h3>Customers</h3>
<table>
<tr><th>Customer</th><th>Email</th><th>Created At</th></tr>
<tr><td>Alice Wong</td><td>alicew@example.com</td><td>2026-05-19 08:32:55</td></tr>
<tr><td>Mike Dong</td><td>miked@example.com</td><td>2026-05-19 08:32:55</td></tr>
<tr><td>Sam Berth</td><td>samb@example.com</td><td>2026-05-19 08:39:12</td></tr>
</table>

<h3>Orders</h3>
<table>
<tr><th>Order Date</th><th>Total Amount</th><th>Status</th><th>Customer ID</th></tr>
<tr><td>2026-01-04</td><td>49.99</td><td>Paid</td><td>1</td></tr>
<tr><td>2026-01-03</td><td>19.50</td><td>Pending</td><td>2</td></tr>
<tr><td>2026-01-02</td><td>120.00</td><td>Paid</td><td>6</td></tr>
</table>

<!-- SQL QUERIES -->
<h2>Sample SQL Queries</h2>

<pre><code>SELECT * FROM customers;</code></pre>

<pre><code>SELECT * FROM orders ORDER BY total_amount DESC;</code></pre>

<pre><code>
SELECT c.customer_id, c.first_name, c.last_name, c.email,
       o.order_id, o.order_date, o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;
</code></pre>

<!-- EXPORT CONFIRMATION -->
<h2>Export Confirmation</h2>
<p>I exported my database as <code>lab04_joyce.sql</code> and saved it in my lab04 folder.</p>

</body>
</html>
