<?php
session_start();
require_once __DIR__ . "/includes/helpers.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: index.php");
  exit;
}

// Collect raw input
$old = [
  "name" => $_POST["name"] ?? "",
  "email" => $_POST["email"] ?? "",
  "course" => $_POST["course"] ?? "",
  "rating" => $_POST["rating"] ?? "",
  "comments" => $_POST["comments"] ?? "",
  "agree" => $_POST["agree"] ?? ""
];

// Clean input (simple)
$name = clean_text((string)$old["name"]);
$email = clean_text((string)$old["email"]);
$course = strtoupper(clean_text((string)$old["course"]));
$rating = clean_text((string)$old["rating"]);
$comments = trim((string)$old["comments"]);
$agree = $old["agree"];

// Validate
$errors = [];

// Name
if ($name === "") {
  $errors["name"] = "Name is required. (validated by PHP)";
} elseif (strlen($name) < 2 || strlen($name) > 50) {
  $errors["name"] = "Name must be 2–50 characters. (validated by PHP)";
} elseif (!preg_match("/^[A-Za-z\\- ]+$/", $name)) {
  $errors["name"] = "Name can only use letters, spaces, and hyphens. (validated by PHP)";
}

// Email
if ($email === "") {
  $errors["email"] = "Email is required. (validated by PHP)";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $errors["email"] = "Email format is invalid. (validated by PHP)";
}

// Course code
if ($course === "") {
  $errors["course"] = "Course code is required. (validated by PHP)";
} elseif (!is_course_code($course)) {
  $errors["course"] = "Course code must be like INTE3363. (validated by PHP)";
}

// Rating
if ($rating === "") {
  $errors["rating"] = "Rating is required. (validated by PHP)";
} elseif (!ctype_digit($rating)) {
  $errors["rating"] = "Rating must be a whole number. (validated by PHP)";
} else {
  $r = (int)$rating;
  if ($r < 1 || $r > 5) {
    $errors["rating"] = "Rating must be between 1 and 5. (validated by PHP)";
  }
}

// Comments (optional)
if ($comments !== "") {
  if (strlen($comments) < 10) {
    $errors["comments"] = "Comments must be at least 10 characters if provided. (validated by PHP)";
  } elseif (strlen($comments) > 500) {
    $errors["comments"] = "Comments must be 500 characters or less. (validated by PHP)";
  }
}

// Agree
if ($agree !== "1") {
  $errors["agree"] = "You must agree before submitting. (validated by PHP)";
}

// If errors → redirect back with session flash data
if (!empty($errors)) {
  $_SESSION["errors"] = $errors;

  $_SESSION["old"] = [
    "name" => $name,
    "email" => $email,
    "course" => $course,
    "rating" => $rating,
    "comments" => $comments,
    "agree" => $agree
  ];

  header("Location: index.php");
  exit;
}

// Success → Save to file (JSON Lines)
$submission = [
  "name" => $name,
  "email" => $email,
  "course" => $course,
  "rating" => (int)$rating,
  "comments" => $comments,
  "created_at" => date("c")
];

$dataFile = __DIR__ . "/data/submissions.jsonl";
$logFile  = __DIR__ . "/logs/errors.log";

try {
  $line = json_encode($submission, JSON_UNESCAPED_UNICODE) . PHP_EOL;

  $ok = file_put_contents($dataFile, $line, FILE_APPEND | LOCK_EX);
  if ($ok === false) {
    throw new Exception("Failed to write submission file.");
  }

  $_SESSION["success"] = "Thank you! Your feedback was saved.";
  header("Location: index.php");
  exit;

} catch (Throwable $ex) {

  $msg = date("c") . " - " . $ex->getMessage() . PHP_EOL;
  @file_put_contents($logFile, $msg, FILE_APPEND);

  $_SESSION["errors"] = [
    "form" => "Sorry — we could not save your feedback. Please try again. (validated by PHP)"
  ];

  $_SESSION["old"] = [
    "name" => $name,
    "email" => $email,
    "course" => $course,
    "rating" => $rating,
    "comments" => $comments,
    "agree" => $agree
  ];

  header("Location: index.php");
  exit;
}