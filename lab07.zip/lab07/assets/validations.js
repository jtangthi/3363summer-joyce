document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#feedbackForm");
  if (!form) return;

  const fields = {
    name: form.querySelector("#name"),
    email: form.querySelector("#email"),
    course: form.querySelector("#course"),
    rating: form.querySelector("#rating"),
    comments: form.querySelector("#comments"),
    agree: form.querySelector("#agree"),
  };

  function setError(fieldName, message) {
    const el = form.querySelector(`[data-err-for="${fieldName}"]`);
    if (!el) return;

    el.textContent = message || "";

    // JS errors should be BLUE (err-js). When cleared, remove the class.
    if (message) {
      el.classList.add("err-js");
    } else {
      el.classList.remove("err-js");
    }
  }

  function clearErrors() {
    Object.keys(fields).forEach((k) => setError(k, ""));
  }

  function isCourseCode(value) {
    return /^INTE\d{4}$/.test(value);
  }

  form.addEventListener("submit", (e) => {
    clearErrors();

    const name = fields.name.value.trim();
    const email = fields.email.value.trim();
    const course = fields.course.value.trim().toUpperCase();
    const ratingStr = fields.rating.value.trim();
    const comments = fields.comments.value.trim();
    const agree = fields.agree.checked;

    let hasError = false;

    // Name
    if (!name) {
      setError("name", "Name is required. (validated by JavaScript)");
      hasError = true;
    } else if (name.length < 2 || name.length > 50) {
      setError("name", "Name must be 2–50 characters. (validated by JavaScript)");
      hasError = true;
    } else if (!/^[A-Za-z\- ]+$/.test(name)) {
      setError("name", "Name can only use letters, spaces, and hyphens. (validated by JavaScript)");
      hasError = true;
    }

    // Email
    if (!email) {
      setError("email", "Email is required. (validated by JavaScript)");
      hasError = true;
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError("email", "Email must look like name@example.com. (validated by JavaScript)");
      hasError = true;
    }

    // Course
    if (!course) {
      setError("course", "Course code is required. (validated by JavaScript)");
      hasError = true;
    } else if (!isCourseCode(course)) {
      setError("course", "Course code must be like INTE3363. (validated by JavaScript)");
      hasError = true;
    } else {
      fields.course.value = course;
    }

    // Rating
    if (!ratingStr) {
      setError("rating", "Rating is required. (validated by JavaScript)");
      hasError = true;
    } else {
      const rating = Number(ratingStr);
      if (!Number.isInteger(rating)) {
        setError("rating", "Rating must be a whole number. (validated by JavaScript)");
        hasError = true;
      } else if (rating < 1 || rating > 5) {
        setError("rating", "Rating must be between 1 and 5. (validated by JavaScript)");
        hasError = true;
      }
    }

    // Comments
    if (comments && comments.length < 10) {
      setError("comments", "Comments must be at least 10 characters if provided. (validated by JavaScript)");
      hasError = true;
    } else if (comments.length > 500) {
      setError("comments", "Comments must be 500 characters or less. (validated by JavaScript)");
      hasError = true;
    }

    // Agree
    if (!agree) {
      setError("agree", "You must agree before submitting. (validated by JavaScript)");
      hasError = true;
    }

    if (hasError) {
      e.preventDefault();
    }
  });
});