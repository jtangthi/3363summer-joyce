# Lab 07 — Validation & Error Handling (JavaScript + PHP)
**Student Name:** Joyce Tang Thi
**Submission Date:** June 3, 2026
## 1) How to Run
1. Start **Apache** in XAMPP.
2. Put this folder in: `C:\xampp\htdocs\3363summer\lab07\`
3. Testing URL: http://localhost/3363summer/lab07/index.php
---
## 2) Files Included (check)
- [v] `index.php`
- [v] `process.php`
- [v] `includes/helpers.php`
- [v] `assets/validation.js`
- [v] `assets/style.css`
- [v] `data/submissions.jsonl`
- [v] `logs/errors.log`
---
## 3) Validation Completed (check)
### JavaScript (client-side)
- [ ] Required fields blocked
- [ ] Email format checked
- [ ] Course code format checked (INTE####)
- [ ] Rating checked (1–5)
- [ ] Agree checkbox required
- [ ] Errors show beside fields
- [ ] Prevent submit when invalid
### PHP (server-side)
- [ ] Validates the same rules again
- [ ] Shows errors beside fields
- [ ] Keeps sticky values (old input stays)
- [ ] Uses `try/catch` for saving file
- [ ] Logs errors to `logs/errors.log`
---
## 4) Testing Checklist (Required)
Fill in Pass/Fail.
| Test | Pass/Fail |
|------|----------|
| Empty submit shows errors | Pass |
| Invalid email blocked | ___ |
| Invalid course code blocked | ___ |
| Rating out of range blocked | ___ |
| Agree unchecked blocked | ___ |
| Disable JS (comment out script tag) → PHP still blocks invalid data | ___ |
| Valid submit saves to `submissions.jsonl` | ___ |
---
## 5) Compare JavaScript vs PHP Validation (What I learned)
Fill in 1–2 sentences for each. 
**JavaScript validation is good for:** 
Fast user feedback, it prevents unnecessary page reloads and shows  errors instantly in the browser
**JavaScript validation is NOT reliable for security because:** 
 Users can disable JavaScript, modify the form, or send requests directly, so JS can bypassed completely
**PHP validation is important because:** 
It is the final authority on the server, it enforces all rules even when JS is diabled or bypassed
**One example from my testing (disable JS) that proved PHP is needed because:** 
When I commented out the <script> tag, the form still blocked invalid submissions and showed “validated by PHP,” proving the server protects the system even without JavaScript